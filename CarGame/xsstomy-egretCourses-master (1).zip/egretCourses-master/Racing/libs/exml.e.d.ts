declare class gameOverSkin extends eui.Skin{
}
declare class gamePlayingSkin extends eui.Skin{
}
declare class gameStartSkin extends eui.Skin{
}
declare class loadingUISkin extends eui.Skin{
}
declare class ttttSkin extends eui.Skin{
}
